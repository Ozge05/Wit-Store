import { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import './components/Layout.css';
import Products from './components/Products';
import SideBar from './components/SideBar';

function App() {
  const [category, setCategory] = useState('electronics');

  const handleCatChange = (newCategory) => {
    setCategory(newCategory);
  };

  return (
    <>
      <Header />
      <div className="content-section">
        <SideBar handleCatChange={handleCatChange} category={category} />
        <Products category={category} />
      </div>
      <Footer />
    </>
  );
}

export default App;
